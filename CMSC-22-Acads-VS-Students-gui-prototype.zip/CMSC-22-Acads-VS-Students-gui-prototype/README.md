# CMSC-22-Acads-VS-Students
Private repository for project in CMSC 22.

## WEEK 1
- Make moving zombies
- Make moving plants
- Make falling energy
- Make Plants and Zombies kill each other.

## WEEK 2
- Implement lanes
- Implement levels

## WEEK 3
- Settings
- File I/O

## WEEK 4
- Finalization
